﻿using System;
using System.IO;

namespace CalculatorApp2
{
    class Logger
    {
        private readonly string logFilePath = @"V:\Celstream Technologies\samples_c#\Week 5 - Revision\CalculatorApp2\log.txt";

        public void LogInput(string input, string methodName)
        {
            Log($"{methodName} - NEW OPERATION: " + $"Input: {input}");
        }

        public void LogOutput(string operation, double result, string methodName)
        {
            Log($"{methodName} - Operation: {operation}, Result: {result}");
        }

        public void LogError(string errorMessage, string methodName)
        {
            Log($"{methodName} - Error: {errorMessage}");
        }

        private void Log(string message)
        {
            try
            {
                string logMessage = $"{DateTime.Now:MM/dd/yyyy hh:mm:ss tt}: {message}";
                using (StreamWriter writer = File.AppendText(logFilePath))
                {
                    writer.WriteLine(logMessage);
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error occurred while logging: {ex.Message}");
            }
        }
    }
}
